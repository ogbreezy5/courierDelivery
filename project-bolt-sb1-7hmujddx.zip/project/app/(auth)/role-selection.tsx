import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { useRouter } from 'expo-router';
import { ArrowLeft } from 'lucide-react-native';

export default function RoleSelectionScreen() {
  const router = useRouter();

  const handleRoleSelection = (role: 'customer' | 'courier') => {
    // In a real app, save the user's role preference
    // For now, just navigate to the main app
    router.push('/(tabs)');
  };

  return (
    <View style={styles.container}>
      <TouchableOpacity 
        style={styles.backButton}
        onPress={() => router.back()}
      >
        <ArrowLeft size={24} color="#333" />
      </TouchableOpacity>
      
      <View style={styles.header}>
        <Text style={styles.title}>Choose Your Role</Text>
        <Text style={styles.subtitle}>Select how you want to use SwiftParcel</Text>
      </View>
      
      <View style={styles.rolesContainer}>
        <TouchableOpacity 
          style={styles.roleCard}
          onPress={() => handleRoleSelection('customer')}
        >
          <Image 
            source={{ uri: 'https://images.unsplash.com/photo-1580674285054-bed31e145f59?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80' }} 
            style={styles.roleImage}
          />
          <View style={styles.roleInfo}>
            <Text style={styles.roleName}>Customer</Text>
            <Text style={styles.roleDescription}>
              Send packages and track deliveries in real-time
            </Text>
          </View>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={styles.roleCard}
          onPress={() => handleRoleSelection('courier')}
        >
          <Image 
            source={{ uri: 'https://images.unsplash.com/photo-1542879379-a0c18549e33b?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80' }} 
            style={styles.roleImage}
          />
          <View style={styles.roleInfo}>
            <Text style={styles.roleName}>Courier</Text>
            <Text style={styles.roleDescription}>
              Deliver packages and earn money on your own schedule
            </Text>
          </View>
        </TouchableOpacity>
      </View>
      
      <Text style={styles.noteText}>
        You can change your role anytime in settings
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
    padding: 24,
  },
  backButton: {
    marginTop: 20,
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    marginTop: 40,
    marginBottom: 40,
    alignItems: 'center',
  },
  title: {
    fontFamily: 'Poppins-Bold',
    fontSize: 28,
    color: '#333',
    marginBottom: 8,
    textAlign: 'center',
  },
  subtitle: {
    fontFamily: 'Poppins-Regular',
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
  },
  rolesContainer: {
    gap: 20,
  },
  roleCard: {
    borderRadius: 16,
    backgroundColor: '#fff',
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
  },
  roleImage: {
    width: '100%',
    height: 180,
  },
  roleInfo: {
    padding: 20,
  },
  roleName: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 20,
    color: '#333',
    marginBottom: 8,
  },
  roleDescription: {
    fontFamily: 'Poppins-Regular',
    fontSize: 14,
    color: '#666',
    lineHeight: 22,
  },
  noteText: {
    fontFamily: 'Poppins-Regular',
    fontSize: 14,
    color: '#999',
    textAlign: 'center',
    marginTop: 24,
  },
});