import { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, Image } from 'react-native';
import { Package, CircleCheck as CheckCircle, Clock, CircleAlert as AlertCircle, ChevronRight } from 'lucide-react-native';

export default function DeliveriesScreen() {
  const [activeTab, setActiveTab] = useState('active');
  
  // Mock data for deliveries
  const activeDeliveries = [
    {
      id: '1',
      title: 'Document Delivery',
      from: '123 Main St, San Francisco',
      to: '456 Market St, San Francisco',
      status: 'In Progress',
      time: '15 min ago',
      image: 'https://images.unsplash.com/photo-1568219656418-15c329312bf1?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      courier: {
        name: 'John Doe',
        rating: 4.8,
        image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      },
    },
    {
      id: '2',
      title: 'Grocery Package',
      from: '789 Oak St, San Francisco',
      to: '101 Pine St, San Francisco',
      status: 'Pickup Scheduled',
      time: '30 min ago',
      image: 'https://images.unsplash.com/photo-1542838132-92c53300491e?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      courier: {
        name: 'Jane Smith',
        rating: 4.9,
        image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      },
    },
  ];
  
  const completedDeliveries = [
    {
      id: '3',
      title: 'Electronics Package',
      from: '222 Valencia St, San Francisco',
      to: '333 Mission St, San Francisco',
      status: 'Delivered',
      time: 'Yesterday',
      image: 'https://images.unsplash.com/photo-1512418490979-92798cec1380?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      courier: {
        name: 'Mike Johnson',
        rating: 4.7,
        image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      },
    },
    {
      id: '4',
      title: 'Gift Package',
      from: '444 Hayes St, San Francisco',
      to: '555 Folsom St, San Francisco',
      status: 'Delivered',
      time: '2 days ago',
      image: 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      courier: {
        name: 'Sarah Williams',
        rating: 4.6,
        image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      },
    },
  ];
  
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'In Progress':
        return <Clock size={16} color="#FF6B00" />;
      case 'Pickup Scheduled':
        return <Clock size={16} color="#3498db" />;
      case 'Delivered':
        return <CheckCircle size={16} color="#2ecc71" />;
      default:
        return <AlertCircle size={16} color="#e74c3c" />;
    }
  };
  
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'In Progress':
        return '#FF6B00';
      case 'Pickup Scheduled':
        return '#3498db';
      case 'Delivered':
        return '#2ecc71';
      default:
        return '#e74c3c';
    }
  };
  
  const renderDeliveryItem = ({ item }: { item: any }) => (
    <TouchableOpacity style={styles.deliveryCard}>
      <View style={styles.deliveryHeader}>
        <View style={styles.deliveryTitleContainer}>
          <Package size={18} color="#333" />
          <Text style={styles.deliveryTitle}>{item.title}</Text>
        </View>
        <View style={[styles.statusBadge, { backgroundColor: `${getStatusColor(item.status)}20` }]}>
          {getStatusIcon(item.status)}
          <Text style={[styles.statusText, { color: getStatusColor(item.status) }]}>{item.status}</Text>
        </View>
      </View>
      
      <View style={styles.deliveryDetails}>
        <View style={styles.locationContainer}>
          <View style={styles.locationDot} />
          <View style={styles.locationLine} />
          <View style={[styles.locationDot, styles.destinationDot]} />
        </View>
        
        <View style={styles.addressContainer}>
          <View style={styles.addressRow}>
            <Text style={styles.addressLabel}>From</Text>
            <Text style={styles.addressText} numberOfLines={1}>{item.from}</Text>
          </View>
          <View style={styles.addressRow}>
            <Text style={styles.addressLabel}>To</Text>
            <Text style={styles.addressText} numberOfLines={1}>{item.to}</Text>
          </View>
        </View>
      </View>
      
      {activeTab === 'active' && (
        <View style={styles.courierContainer}>
          <Image source={{ uri: item.courier.image }} style={styles.courierImage} />
          <View style={styles.courierInfo}>
            <Text style={styles.courierName}>{item.courier.name}</Text>
            <View style={styles.ratingContainer}>
              <Text style={styles.ratingText}>{item.courier.rating}</Text>
              <Text style={styles.ratingLabel}>Rating</Text>
            </View>
          </View>
          <TouchableOpacity style={styles.trackButton}>
            <Text style={styles.trackButtonText}>Track</Text>
          </TouchableOpacity>
        </View>
      )}
      
      <View style={styles.cardFooter}>
        <Text style={styles.timeText}>{item.time}</Text>
        <TouchableOpacity style={styles.detailsButton}>
          <Text style={styles.detailsButtonText}>Details</Text>
          <ChevronRight size={16} color="#FF6B00" />
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );
  
  const renderEmptyList = () => (
    <View style={styles.emptyContainer}>
      <Package size={60} color="#DDD" />
      <Text style={styles.emptyTitle}>No deliveries found</Text>
      <Text style={styles.emptySubtitle}>
        {activeTab === 'active' 
          ? "You don't have any active deliveries" 
          : "You don't have any completed deliveries"}
      </Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>My Deliveries</Text>
        <View style={styles.tabContainer}>
          <TouchableOpacity 
            style={[styles.tab, activeTab === 'active' && styles.activeTab]}
            onPress={() => setActiveTab('active')}
          >
            <Text 
              style={[styles.tabText, activeTab === 'active' && styles.activeTabText]}
            >
              Active
            </Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={[styles.tab, activeTab === 'completed' && styles.activeTab]}
            onPress={() => setActiveTab('completed')}
          >
            <Text 
              style={[styles.tabText, activeTab === 'completed' && styles.activeTabText]}
            >
              Completed
            </Text>
          </TouchableOpacity>
        </View>
      </View>
      
      <FlatList
        data={activeTab === 'active' ? activeDeliveries : completedDeliveries}
        renderItem={renderDeliveryItem}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listContainer}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={renderEmptyList}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FA',
  },
  header: {
    backgroundColor: '#ffffff',
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 20,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 5,
  },
  headerTitle: {
    fontFamily: 'Poppins-Bold',
    fontSize: 24,
    color: '#333',
    marginBottom: 20,
  },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: '#F5F5F5',
    borderRadius: 12,
    padding: 4,
  },
  tab: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
    borderRadius: 10,
  },
  activeTab: {
    backgroundColor: '#ffffff',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  tabText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: '#999',
  },
  activeTabText: {
    color: '#333',
  },
  listContainer: {
    padding: 20,
    paddingBottom: 100,
  },
  deliveryCard: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 3,
  },
  deliveryHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  deliveryTitleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  deliveryTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 16,
    color: '#333',
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    gap: 4,
  },
  statusText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 12,
  },
  deliveryDetails: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  locationContainer: {
    width: 20,
    alignItems: 'center',
    marginRight: 12,
  },
  locationDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: '#FF6B00',
  },
  locationLine: {
    width: 2,
    height: 30,
    backgroundColor: '#E0E0E0',
    marginVertical: 4,
  },
  destinationDot: {
    backgroundColor: '#333',
  },
  addressContainer: {
    flex: 1,
    gap: 16,
  },
  addressRow: {
    gap: 4,
  },
  addressLabel: {
    fontFamily: 'Poppins-Regular',
    fontSize: 12,
    color: '#999',
  },
  addressText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: '#333',
  },
  courierContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F8F9FA',
    borderRadius: 12,
    padding: 12,
    marginBottom: 16,
  },
  courierImage: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 12,
  },
  courierInfo: {
    flex: 1,
  },
  courierName: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    color: '#333',
    marginBottom: 2,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  ratingText: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 12,
    color: '#FF6B00',
  },
  ratingLabel: {
    fontFamily: 'Poppins-Regular',
    fontSize: 12,
    color: '#999',
  },
  trackButton: {
    backgroundColor: '#FF6B00',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
  },
  trackButtonText: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 12,
    color: '#ffffff',
  },
  cardFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderTopWidth: 1,
    borderTopColor: '#F0F0F0',
    paddingTop: 12,
  },
  timeText: {
    fontFamily: 'Poppins-Regular',
    fontSize: 12,
    color: '#999',
  },
  detailsButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  detailsButtonText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 12,
    color: '#FF6B00',
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
  },
  emptyTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 18,
    color: '#333',
    marginTop: 16,
    marginBottom: 8,
  },
  emptySubtitle: {
    fontFamily: 'Poppins-Regular',
    fontSize: 14,
    color: '#999',
    textAlign: 'center',
  },
});