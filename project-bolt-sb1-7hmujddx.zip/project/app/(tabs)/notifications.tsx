import { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, Image } from 'react-native';
import { Bell, Package, CircleCheck as CheckCircle, Clock, CircleAlert as AlertCircle, ChevronRight } from 'lucide-react-native';

export default function NotificationsScreen() {
  // Mock data for notifications
  const notifications = [
    {
      id: '1',
      title: 'Delivery Update',
      message: 'Your package is on the way! Estimated delivery time: 2:30 PM.',
      time: '15 min ago',
      read: false,
      type: 'delivery',
    },
    {
      id: '2',
      title: 'Courier Assigned',
      message: 'John Doe has been assigned to deliver your package.',
      time: '30 min ago',
      read: false,
      type: 'courier',
    },
    {
      id: '3',
      title: 'Delivery Completed',
      message: 'Your package has been delivered successfully. Please rate your experience!',
      time: '2 hours ago',
      read: true,
      type: 'completed',
    },
    {
      id: '4',
      title: 'Special Offer',
      message: 'Get 20% off on your next delivery! Use code: SWIFT20',
      time: 'Yesterday',
      read: true,
      type: 'promo',
    },
    {
      id: '5',
      title: 'Payment Confirmed',
      message: 'Your payment of $15.50 for delivery #12345 has been confirmed.',
      time: '2 days ago',
      read: true,
      type: 'payment',
    },
  ];
  
  const getNotificationIcon = (type: string, read: boolean) => {
    const color = read ? '#999' : '#FF6B00';
    
    switch (type) {
      case 'delivery':
        return <Package size={24} color={color} />;
      case 'courier':
        return <Clock size={24} color={color} />;
      case 'completed':
        return <CheckCircle size={24} color={color} />;
      case 'promo':
        return <Bell size={24} color={color} />;
      case 'payment':
        return <AlertCircle size={24} color={color} />;
      default:
        return <Bell size={24} color={color} />;
    }
  };
  
  const renderNotificationItem = ({ item }: { item: any }) => (
    <TouchableOpacity 
      style={[
        styles.notificationCard, 
        !item.read && styles.unreadNotification
      ]}
    >
      <View style={styles.notificationIconContainer}>
        {getNotificationIcon(item.type, item.read)}
      </View>
      <View style={styles.notificationContent}>
        <View style={styles.notificationHeader}>
          <Text style={styles.notificationTitle}>{item.title}</Text>
          <Text style={styles.notificationTime}>{item.time}</Text>
        </View>
        <Text style={styles.notificationMessage}>{item.message}</Text>
      </View>
    </TouchableOpacity>
  );
  
  const renderEmptyList = () => (
    <View style={styles.emptyContainer}>
      <Bell size={60} color="#DDD" />
      <Text style={styles.emptyTitle}>No notifications</Text>
      <Text style={styles.emptySubtitle}>
        You don't have any notifications at the moment
      </Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Notifications</Text>
        <TouchableOpacity style={styles.clearButton}>
          <Text style={styles.clearButtonText}>Clear All</Text>
        </TouchableOpacity>
      </View>
      
      <FlatList
        data={notifications}
        renderItem={renderNotificationItem}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listContainer}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={renderEmptyList}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FA',
  },
  header: {
    backgroundColor: '#ffffff',
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 20,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 5,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerTitle: {
    fontFamily: 'Poppins-Bold',
    fontSize: 24,
    color: '#333',
  },
  clearButton: {
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 8,
    backgroundColor: '#F5F5F5',
  },
  clearButtonText: {
    fontFamily: 'Poppins-Medium',
    fontSize: 12,
    color: '#666',
  },
  listContainer: {
    padding: 20,
    paddingBottom: 100,
  },
  notificationCard: {
    flexDirection: 'row',
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  unreadNotification: {
    borderLeftWidth: 4,
    borderLeftColor: '#FF6B00',
  },
  notificationIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#F5F5F5',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  notificationContent: {
    flex: 1,
  },
  notificationHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 6,
  },
  notificationTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 16,
    color: '#333',
  },
  notificationTime: {
    fontFamily: 'Poppins-Regular',
    fontSize: 12,
    color: '#999',
  },
  notificationMessage: {
    fontFamily: 'Poppins-Regular',
    fontSize: 14,
    color: '#666',
    lineHeight: 20,
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
  },
  emptyTitle: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 18,
    color: '#333',
    marginTop: 16,
    marginBottom: 8,
  },
  emptySubtitle: {
    fontFamily: 'Poppins-Regular',
    fontSize: 14,
    color: '#999',
    textAlign: 'center',
  },
});