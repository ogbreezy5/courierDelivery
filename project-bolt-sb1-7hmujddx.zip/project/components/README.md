# Components Directory

This directory contains reusable components for the SwiftParcel app.

## Component Structure

Each component should be organized in its own directory with the following structure:

```
ComponentName/
  ├── index.tsx       # Main component file
  ├── styles.ts       # Component styles
  └── types.ts        # TypeScript types and interfaces
```

## Best Practices

1. Keep components small and focused on a single responsibility
2. Use proper TypeScript typing for all props
3. Follow the established styling patterns using StyleSheet.create
4. Document complex components with comments
5. Test components thoroughly